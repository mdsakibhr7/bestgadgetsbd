<?php
/**
 * Class Functions
 *
 * @author Pluginbazar
 */

use WPDK\Utils;

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( 'BGBDTOOLS_Functions' ) ) {
	class BGBDTOOLS_Functions {
	}
}

global $bgbd_tools;
$bgbd_tools = new BGBDTOOLS_Functions();