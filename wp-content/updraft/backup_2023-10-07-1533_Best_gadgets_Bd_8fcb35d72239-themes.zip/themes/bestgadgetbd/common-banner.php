<?php
/* Template Name: Common Banner */
?>

<section class="single-page-banner">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="banner-page-content text-center">
                    <h1>Apple iPhone 14 Pro</h1>
                    <p>Home <span>Apple iPhone14 Pro</span></p>
                </div>
            </div>
        </div>
    </div>
</section>



