<?php

?>
<section class="part-banner">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="banner-page-content text-center">
                    <h1>Apple iPhone 14 Pro</h1>
                    <p>Home
                        <svg xmlns="http://www.w3.org/2000/svg" width="10" height="10" viewBox="0 0 10 10" fill="none">
                            <path d="M1 1L5 5L1 9" stroke="white"/>
                            <path d="M5 1L9 5L5 9" stroke="white"/>
                        </svg>
                        <span>Apple iPhone14 Pro</span></p>
                </div>
            </div>
        </div>
    </div>
</section>
