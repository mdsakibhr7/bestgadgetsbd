<?php

/* Template Name: Category */
get_header();

?>



<?php
get_footer();
?>
