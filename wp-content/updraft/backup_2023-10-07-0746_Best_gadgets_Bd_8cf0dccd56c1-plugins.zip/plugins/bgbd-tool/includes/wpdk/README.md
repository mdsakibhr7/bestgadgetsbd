# WP Plugin Development Kit

WP Plugin Development Kit (WPDK) is a small but powerful tool that helps developers to build WordPress Plugin easily and maintain them properly.

****

### FEATURES

* Create Custom Post Type
* Create Taxonomy
* Create Shortcode
* Send **Notification** to the Plugin Users
* Manage **Updates of Pro version** from your service website
* Create **Settings** page and **Metabox** easily. 


### CREDIT

Thank you for the following services. 

* [Code Star Framework](https://codestarframework.com/)