<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the #content div and all content after.
 *
 * @link    https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Newspaper X
 */

?>
</div><!-- #content -->

</div><!-- #page -->


<div class="footer">
    <div class="container footer-main-menu">
        <div class="row">
            <div class="col-md-6 col-lg-4">
                <h2 class="footer-logo">Mobile <span>Shop</span></h2>
                <p class="bgbd-about">
                    Mobile Shop.com aims to be the most useful and trusted mobile phone info website in Bangladesh.
                    The goal is to help the growing number of users and buyers with all the vital info they need about the phone industry and their gadgets.
                </p>
                <div class="icons">
                    <a href="#"><i class="fa fa-facebook"></i></a>
                    <a href="#"><i class="fa fa-twitter"></i></a>
                    <a href="#"><i class="fa fa-linkedin"></i></a>
                    <a href="#"><i class="fa fa-instagram"></i></a>
                </div>
            </div>
            <div class="col-md-6 col-lg-3 pl">
                <h2 class="footer-title">Explore</h2>
                <div class="footer-menu">
                    <a href="#"> About Us</a>
                    <a href="#"> Privacy Policy</a>
                    <a href="#"> Cookie Policy</a>
                    <a href="#"> Terms & Conditions</a>
                    <a href="#"> Why Shop With Us</a>
                </div>
            </div>
            <div class="col-md-6 col-lg-2">
                <h2 class="footer-title">Price Range</h2>
                <div class="price-range">
                    <h6>1 - 5,000</h6>
                    <h6>5,000 - 10,000</h6>
                    <h6>10,000 - 20,000</h6>
                    <h6>20,000 - 30,000</h6>
                    <h6>30,000 - 40,000</h6>
                </div>
            </div>
            <div class="col-md-6 col-lg-3">
                <h2 class="footer-title">New Mobile Phones</h2>
                <div class="new-mobile-phn">
                    <h6>Itel Ace 2 Power</h6>
                    <h6>Nokia 105 2023 Dual</h6>
                    <h6>Infinix Hot 30 5G 8GB R</h6>
                    <h6>Samsung Galaxy S21</h6>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="copy-right">
                    <div class="copy-right-text">
                        <p>© 2023 Mobile Shop | All rights reserved</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php

wp_footer(); ?>


</body>
</html>
