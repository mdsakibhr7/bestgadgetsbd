// (function ($, window, document, pluginObject) {
//     // "use strict";
//     // $().ready(function () {
//     //     $('.slick-carousel').slick({
//     //         arrows: true,
//     //         centerPadding: "0px",
//     //         dots: true,
//     //         slidesToShow: 1,
//     //         infinite: false
//     //     });
//     // });
//     alert('ok');
//
// });

