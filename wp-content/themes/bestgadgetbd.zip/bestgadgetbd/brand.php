<?php

/* Template Name: Brands */
get_header();

?>

<?php
get_template_part( 'templates-parts/part-banner' );
get_template_part( 'templates-parts/popular-brand' );
?>

<?php
get_footer();
?>
